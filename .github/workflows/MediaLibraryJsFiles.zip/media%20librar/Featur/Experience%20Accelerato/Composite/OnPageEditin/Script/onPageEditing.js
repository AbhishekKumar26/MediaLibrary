var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({
                __proto__: []
            }
            instanceof Array && function (d, b) {
                d.__proto__ = b;
            }) ||
        function (d, b) {
            for (var p in b)
                if (b.hasOwnProperty(p)) d[p] = b[p];
        };
    return function (d, b) {
        extendStatics(d, b);

        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var SXA;
(function (SXA) {
    var Common;
    (function (Common) {
        var ProxyOrder;
        (function (ProxyOrder) {
            ProxyOrder[ProxyOrder["Before"] = 0] = "Before";
            ProxyOrder[ProxyOrder["After"] = 1] = "After";
        })(ProxyOrder = Common.ProxyOrder || (Common.ProxyOrder = {}));
        var HtmlHelpers = (function () {
            function HtmlHelpers() {}
            HtmlHelpers.addProxy = function (operand, functionName, proxyFn, order) {
                if (order === void 0) {
                    order = ProxyOrder.Before;
                }
                if (typeof operand == "function") {
                    if (order === ProxyOrder.Before) {
                        return this.addProxyBeforeToFunction(operand, functionName, proxyFn);
                    } else {
                        return this.addProxyAfterToFunction(operand, functionName, proxyFn);
                    }
                } else {
                    if (order === ProxyOrder.Before) {
                        return this.addProxyBeforeToObject(operand, functionName, proxyFn);
                    } else {
                        return this.addProxyAfterToObject(operand, functionName, proxyFn);
                    }
                }
            };
            HtmlHelpers.parseQuery = function (queryString) {
                var query = {};
                var a = (queryString[0] === "?" ? queryString.substr(1) : queryString).split("&");
                for (var i = 0; i < a.length; i++) {
                    var b = a[i].split("=");
                    query[decodeURIComponent(b[0])] = decodeURIComponent(b[1] || "");
                }
                return query;
            };
            HtmlHelpers.toQuery = function (queryStringObject) {
                return Object.keys(queryStringObject).map(function (key) {
                    return key + '=' + queryStringObject[key];
                }).join('&');
            };
            HtmlHelpers.addProxyBeforeToFunction = function (fn, functionName, proxyFn) {
                var proxied = fn.prototype[functionName];
                fn.prototype[functionName] = function () {
                    try {
                        proxyFn(arguments);
                    } catch (error) {
                        HtmlHelpers.logError(error);
                    }
                    var result = proxied.apply(this, arguments);
                    return result;
                };
            };
            HtmlHelpers.addProxyBeforeToObject = function (obj, functionName, proxyFn) {
                var proxied = obj[functionName];
                obj[functionName] = function () {
                    try {
                        proxyFn(arguments);
                    } catch (error) {
                        HtmlHelpers.logError(error);
                    }
                    var result = proxied.apply(this, arguments);
                    return result;
                };
            };
            HtmlHelpers.addProxyAfterToFunction = function (fn, functionName, proxyFn) {
                var proxied = fn.prototype[functionName];
                fn.prototype[functionName] = function () {
                    var result = proxied.apply(this, arguments);
                    try {
                        proxyFn(arguments);
                    } catch (error) {
                        this.logError(error);
                    }
                    return result;
                };
            };
            HtmlHelpers.addProxyAfterToObject = function (obj, functionName, proxyFn) {
                var proxied = obj[functionName];
                obj[functionName] = function () {
                    var result = proxied.apply(this, arguments);
                    try {
                        proxyFn(arguments);
                    } catch (error) {
                        this.logError(error);
                    }
                    return result;
                };
            };
            HtmlHelpers.logError = function (error) {
                console.log("[SXA] An error occurred in the proxy function.");
                console.log(error);
            };
            return HtmlHelpers;
        }());
        Common.HtmlHelpers = HtmlHelpers;
    })(Common = SXA.Common || (SXA.Common = {}));
})(SXA || (SXA = {}));
(function (SXA) {
    var Feature;
    (function (Feature) {
        var Composites;
        (function (Composites) {
            var Rendering = (function () {
                function Rendering(rawRendering) {
                    this.rawRendering = rawRendering;
                    this.placeholder = rawRendering["@ph"];
                    this.uniqueId = rawRendering["@uid"];
                    this.parameters = SXA.Common.HtmlHelpers.parseQuery(rawRendering["@par"]);
                    this.dynamicPlaceholderId = this.parameters["DynamicPlaceholderId"];
                }
                Rendering.prototype.remove = function () {
                    var controlId = this.uniqueId.replace(/[-{}]/g, "");
                    Sitecore.LayoutDefinition.remove(controlId);
                };
                Rendering.prototype.markAsModified = function () {
                    var modifiedFlag = false;
                    var layoutDefinition = Sitecore.LayoutDefinition.getLayoutDefinition();
                    var currentDevice = Sitecore.LayoutDefinition.getDevice(layoutDefinition);
                    if (!currentDevice) {
                        return null;
                    }
                    var allDevices = layoutDefinition.r.d;
                    for (var m = 0; m < allDevices.length; m++) {
                        if (allDevices[m]["@id"] == currentDevice["@id"]) {
                            for (var n = 0; n < allDevices[m].r.length; n++) {
                                if (allDevices[m].r[n]["@uid"] == this.uniqueId) {
                                    var renderingParameters = allDevices[m].r[n]["@par"];
                                    var parametersObject = SXA.Common.HtmlHelpers.parseQuery(renderingParameters);
                                    parametersObject["onPageEditingOfCompositesState"] = this.uniqueId;
                                    allDevices[m].r[n]["@par"] = SXA.Common.HtmlHelpers.toQuery(parametersObject);
                                    modifiedFlag = true;
                                    break;
                                }
                            }
                        }
                    }
                    if (modifiedFlag) {
                        Sitecore.LayoutDefinition.setLayoutDefinition(layoutDefinition);
                    }
                };
                return Rendering;
            }());
            Composites.Rendering = Rendering;
            var Context = (function () {
                function Context() {}
                Context.onPageEditingEnabled = function () {
                    try {
                        if (Sitecore.PageModes.PageEditor.onPageEditingOfComposites == null) {
                            return false;
                        } else {
                            return Sitecore.PageModes.PageEditor.onPageEditingOfComposites();
                        }
                    } catch (_a) {
                        return false;
                    }
                };
                return Context;
            }());
            Composites.Context = Context;
            var OnPageEditingService = (function () {
                function OnPageEditingService() {}
                OnPageEditingService.prototype.init = function () {
                    var _this = this;
                    var originalRendering = Sitecore.PageModes.ChromeTypes.Rendering.prototype;
                    SXA.Common.HtmlHelpers.addProxy(originalRendering, "deleteControl", function (args) {
                        _this.onRenderingRemove(args);
                    }, SXA.Common.ProxyOrder.Before);
                    SXA.Common.HtmlHelpers.addProxy(originalRendering, "deleteControl", function (args) {
                        _this.onRenderingRemoveMarkAsModified(args);
                    }, SXA.Common.ProxyOrder.Before);
                };
                OnPageEditingService.prototype.getRemovedRendering = function (args) {
                    var data = args[0];
                    var removedRenderingId = data._originalDOMElement.context.id.replace("r_", "");
                    var rendering = new Rendering(Sitecore.LayoutDefinition.getRendering(removedRenderingId));
                    return rendering;
                };
                OnPageEditingService.prototype.getAllRenderings = function () {
                    var rawRenderings = Sitecore.LayoutDefinition.getRenderings();
                    var allRenderings = $xa.map(rawRenderings, function (raw) {
                        return new Rendering(raw);
                    });
                    return allRenderings;
                };
                OnPageEditingService.prototype.onRenderingRemove = function (args) {
                    var rendering = this.getRemovedRendering(args);
                    var allRenderings = this.getAllRenderings();
                    var pattern = "/" + rendering.placeholder + "/section-([title|content])+-\\d+-" + rendering.dynamicPlaceholderId;
                    var compositeRenderings = $xa.grep(allRenderings, function (r) {
                        return r.placeholder.match(new RegExp(pattern, "g")) != null;
                    });
                    $xa.each(compositeRenderings, function (index, r) {
                        return r.remove();
                    });
                };
                OnPageEditingService.prototype.onRenderingRemoveMarkAsModified = function (args) {
                    var rendering = this.getRemovedRendering(args);
                    var allRenderings = this.getAllRenderings();
                    var placeholder = new Composites.Placeholder(rendering.placeholder);
                    var compositeSectionPlaceholder = placeholder.GetCompositeSectionPlaceholder();
                    if (compositeSectionPlaceholder != null) {
                        var compositeDynamicPlaceholderID_1 = compositeSectionPlaceholder.match(/section-([title|content])+-\d+-(.*)/)[2];
                        var compositePlaceholderName_1 = placeholder.GetCompositePlaceholderName();
                        var compositeRenderings = $xa.grep(allRenderings, function (r) {
                            return r.placeholder == compositePlaceholderName_1 && r.dynamicPlaceholderId == compositeDynamicPlaceholderID_1;
                        });
                        $xa.each(compositeRenderings, function (index, r) {
                            return r.markAsModified();
                        });
                    }
                };
                return OnPageEditingService;
            }());
            Composites.OnPageEditingService = OnPageEditingService;
            var CompositesInitHandler = (function () {
                function CompositesInitHandler() {
                    this.compositeModulesNames = new Array();
                    this.compositeModulesNames.push("carousels");
                    this.compositeModulesNames.push("tabs");
                    this.compositeModulesNames.push("flip");
                    this.compositeModulesNames.push("accordions");
                    this.compositeModulesNames.push("snippet");
                }
                CompositesInitHandler.prototype.process = function (name, module) {
                    if (this.compositeModulesNames.indexOf(name) > -1) {
                        this.performAction(name, module);
                    }
                };
                return CompositesInitHandler;
            }());
            Composites.CompositesInitHandler = CompositesInitHandler;
            var CompositesPreInitHandler = (function (_super) {
                __extends(CompositesPreInitHandler, _super);

                function CompositesPreInitHandler() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                CompositesPreInitHandler.prototype.performAction = function (name, module) {
                    var disabledPlaceholders = window.top.document.querySelectorAll(".scEmptyPlaceholder");
                    for (var index = 0; index < disabledPlaceholders.length; index++) {
                        var ph = disabledPlaceholders[index];
                        ph.classList.remove("scEmptyPlaceholder");
                        ph.classList.add("scEmptyPlaceholderSxa");
                    }
                };
                return CompositesPreInitHandler;
            }(CompositesInitHandler));
            Composites.CompositesPreInitHandler = CompositesPreInitHandler;
            var CompositesPostInitHandler = (function (_super) {
                __extends(CompositesPostInitHandler, _super);

                function CompositesPostInitHandler() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                CompositesPostInitHandler.prototype.performAction = function (name, module) {
                    var disabledPlaceholders = window.top.document.querySelectorAll(".scEmptyPlaceholderSxa");
                    for (var index = 0; index < disabledPlaceholders.length; index++) {
                        var ph = disabledPlaceholders[index];
                        ph.classList.remove("scEmptyPlaceholderSxa");
                        ph.classList.add("scEmptyPlaceholder");
                    }
                };
                return CompositesPostInitHandler;
            }(CompositesInitHandler));
            Composites.CompositesPostInitHandler = CompositesPostInitHandler;
        })(Composites = Feature.Composites || (Feature.Composites = {}));
    })(Feature = SXA.Feature || (SXA.Feature = {}));
})(SXA || (SXA = {}));
(function (SXA) {
    var Feature;
    (function (Feature) {
        var Composites;
        (function (Composites) {
            if (Composites.Context.onPageEditingEnabled()) {
                var service = new SXA.Feature.Composites.OnPageEditingService();
                service.init();
                var preHandler = new SXA.Feature.Composites.CompositesPreInitHandler();
                var postHandler = new SXA.Feature.Composites.CompositesPostInitHandler();
                XA.registerOnPreInitHandler(preHandler);
                XA.registerOnPostInitHandler(postHandler);
            }
        })(Composites = Feature.Composites || (Feature.Composites = {}));
    })(Feature = SXA.Feature || (SXA.Feature = {}));
})(SXA || (SXA = {}));
