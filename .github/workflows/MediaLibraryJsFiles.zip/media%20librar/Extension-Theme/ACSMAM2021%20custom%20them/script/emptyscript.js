jQuery(document).ready(function(){
	jQuery('.sxa-bullets').on('click',function(){document.activeElement.blur()});

	jQuery('.ACSMAM-vendor').find('main .component-content:first')
	.css('color','#ffffff')
	.css('font-size','32px')
	.css('margin', '26px 24px')
	.css('font-weight', '500');

	jQuery('.ACSMAM-vendor .field-link:empty').each(function() {
		var $this = jQuery(this);
		if ($this.html().replace(/\s|&nbsp;/g, '').length == 0) {
			$this.parent().remove();
		}

	})

	jQuery('.ACSMAM-vendor .field-link a.media-icons').each(function() {
		var $this = jQuery(this);
		if ($this[0].attributes[0].name !== 'href') {
			$this.parent().remove();
		}
	})

	jQuery('.ACSMAM-vendor .media-contact-item .contact-item-image.field-image img').each(function() {
		var $this = jQuery(this);
		$this.removeAttr('sizes');
		$this.removeAttr('srcset');
		const newSrc = $this[0].src.replace('w=56&','');
		$this.attr('src',newSrc);
	})

	let domain = window.location.origin;
	const learnMoreLink = document.createElement('a');
	const leaderboard = jQuery('.ACSMAM-body .ldi-leaderboard__header');

	learnMoreLink.innerHTML = 'Learn More';
	learnMoreLink.href =`${domain}/en/hub/engage/games`;
	leaderboard.text(`${leaderboard.html()} - `);
	leaderboard.append(learnMoreLink);

	if(window.document.body.classList.contains("ACSMAM-awards")) {
		jQuery('.ACSMAM-awards iframe[id^="iFrameResizer"]').css('display','none');
	}
});

window.onload = function() {
	if(window.document.body.classList.contains("ACSMAM-awards")) {
		setTimeout(function() {
			jQuery("body").focus();
			jQuery('.ACSMAM-awards iframe[id^="iFrameResizer"]').css('display','block');
		}, 3000);
		
	}
}