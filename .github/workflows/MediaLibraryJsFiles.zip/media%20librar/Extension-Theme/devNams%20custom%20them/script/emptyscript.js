function empty(){
	var instructions = "put your site custom JS here"
	return instructions;
}