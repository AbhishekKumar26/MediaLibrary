jQuery(document).ready(function(){

	jQuery('.ACSM-carousel-slide .slide-info .field-slidelink').addClass('wkbutton');
	jQuery('.cards .link-wrapper .card-content .card-cta').addClass('wkbutton');
	jQuery('.ACSM-callout-small .callout-wrapper .callout-content a').addClass('wkbutton');
	jQuery('.ACSM-callout-large .callout-wrapper .callout-content a').addClass('wkbutton');
	jQuery('.ACSM-callout-container .featured-content-with-image--content a').addClass('wkbutton');
	jQuery('.callout .callout-wrapper .callout-content .callout-cta a').addClass('wkbutton');
	jQuery('.ACSM-carousel .slide-info .field-slidelink').addClass('wkbutton');

	jQuery('.ACSM-vendor-main .component-content').find(':not(img)').wrapAll('<div class="inner-container"></div>');

	//markup clean-up
	jQuery('.ACSM-body #footer .legal-footer h3').removeAttr('style');
	jQuery('span').removeAttr('style');

	jQuery('.ldi-profile-card .wkbutton').on('click', function(){
        var ep = window.ldi_user.gamificationEndpoint;
        var url = window.location.href;
        var event = 'init-1-1-chat';
        var eventData = {
            "message":event,
            "url":url
        }
        jQuery.ajax({
            type:'POST',
            url:ep,
            contentType: 'application/json',
            data:JSON.stringify(eventData)
        })
    });

	jQuery('.ldi-search-results__container').each(function(ix){
        var  observer = new MutationObserver(function(){
            jQuery('.ldi-search-results__container .ldi-card-result__cta').not('.ldi-chat-event-applied').filter(function(){
                return jQuery(this).prop('href').indexOf('/ldi-api/chat/create') > -1;
            }).on('click', function(){
                jQuery.ajax({
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify(request),
                    url: window.ldi_user.gamificationEndpoint
                });
            }).addClass('ldi-chat-event-applied');
        });
        var request = {
            "url": window.location.href,
            "message": "init-1-1-chat"
        };
        var config = {subtree:true,
            childList: true};
        observer.observe(this, config);
    });

	//event handeler for cedit profile form
	var profileButtons = jQuery(".ldi-user-information-form button");
	if(profileButtons.length && window.ldi_user){
		profileButtons.prop('id', 'ldi-login-click-profile-updated');
		const eventsLogger = new GamificationEventsLoger(window.ldi_user);
		eventsLogger.init();
	}

});