'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/* eslint-env es6 */
var $j = jQuery.noConflict();

var LDISearchResults = function () {
    function LDISearchResults(optiions) {
        _classCallCheck(this, LDISearchResults);

        this.$element = optiions.element;
        this.$resultsContainer = this.$element.find('.search-results-container');
        this.$resultsTitle = this.$element.find('.search-results-title');
        this.$noResultsMessage = this.$element.find('.no-results-message');
        this.titleText = this.$element.data('header-text') || '';
        this.noResultsText = this.$element.data('no-result-message') || '';
        this.profileLabel = this.$element.data('profile-button-label') || '';
        this.sendMessageLabel = this.$element.data('send-message-button-label') || '';
        this.apiUrl = this.$element.data('api-path') || '';
        this.avatarList = this.$element.data('avatar-list') || [];
        this.pageSettings = window.ldi_user;
        this.loggerApiUrl = this.pageSettings.gamificationEndpoint;
        this.callToApiFlag = true;
        this.requestQuery = {
            'Criteria': window.SearchController.parseURLparams()['q'] || '',
            'Skip': 0,
            'Count': 10
        };
        this.requestQuery.Count = this.$element.data('count') || 10;
        this.renderTilte = true;
    }

    _createClass(LDISearchResults, [{
        key: 'init',
        value: function init() {
            var _this = this;

            this.postRequest();

            $j(window).on('ldi-search:Result', function () {
                var _latestResponse = _this.latestResponse,
                    TotalCount = _latestResponse.TotalCount,
                    Items = _latestResponse.Items;
                //Prevent rendering title on scroll

                if (_this.renderTilte) {
                    _this.setResultsTitle(TotalCount);
                    _this.renderTilte = false;
                }

                if (TotalCount > 0) {
                    _this.updateSkip();
                    _this.setProfileCards(Items);
                } else {
                    _this.showNoResults();
                    _this.callToApiFlag = false;
                }

                if (Items.length < _this.requestQuery.Count) {
                    _this.callToApiFlag = false;
                }
            }).on('scroll', function () {
                return _this.lazyLoadHandler();
            });
        }
    }, {
        key: 'setProfileCards',
        value: function setProfileCards(items) {
            var _this2 = this;

            var getRandomAvatar = function getRandomAvatar(items) {
                return items.length ? items[Math.floor(Math.random() * items.length)] : '';
            };

            var truncateBio = function truncateBio(text) {
                if (!text) {
                    return '';
                }
                return text.length < 150 ? text : text.slice(0, 150) + '...';
            };

            var profileCards = items.map(function (profile) {
                var user = Object.keys(profile).filter(function (key) {
                    return profile[key] != null;
                }).reduce(function (a, key) {
                    return Object.assign(a, _defineProperty({}, key, profile[key]));
                }, {});
                var _user$firstName = user.firstName,
                    firstName = _user$firstName === undefined ? '' : _user$firstName,
                    _user$lastName = user.lastName,
                    lastName = _user$lastName === undefined ? '' : _user$lastName,
                    _user$title = user.title,
                    title = _user$title === undefined ? '' : _user$title,
                    _user$city = user.city,
                    city = _user$city === undefined ? '' : _user$city,
                    _user$state = user.state,
                    state = _user$state === undefined ? '' : _user$state,
                    _user$aboutMe = user.aboutMe,
                    aboutMe = _user$aboutMe === undefined ? '' : _user$aboutMe,
                    _user$userId = user.userId,
                    userId = _user$userId === undefined ? '' : _user$userId;


                return '<article class="ldi-card-result">\n                    <div class="ldi-card-result__avatar">\n                        <img src="' + getRandomAvatar(_this2.avatarList) + '" alt="' + firstName + ' ' + lastName + '" />\n                    </div>\n                    <div class="ldi-card-result__container">\n                        <h3 class="ldi-card-result__user-title">' + firstName + ' ' + lastName + ' ' + title + '</h3>\n                        <p class="ldi-card-result__user-label">' + (city ? city + ',' : '') + ' ' + state + '</p>\n                        <p class="ldi-card-result__user-bio">' + truncateBio(aboutMe) + '</p>\n                        <div class="ldi-card-result__buttons-holder">\n                            <a href="' + _this2.pageSettings.pageSettings.profilePage + '?userid=' + userId + '" class="ldi-card-result__cta">\n                                ' + _this2.profileLabel + '\n                                <span class="wk-icon-arrow-right"></span>\n                            </a>\n                            <a href="' + _this2.pageSettings.createChatEndpoint + '?recipientUserId=' + userId + '" class="ldi-card-result__cta ldi-chat-init-action">\n                                ' + _this2.sendMessageLabel + '\n                                <span class="wk-icon-arrow-right"></span>\n                            </a>\n                        <div>\n                    </div>\n                </article>';
            });

            this.$resultsContainer.append(profileCards);
            this.setGamificationEvents();
        }
    }, {
        key: 'setGamificationEvents',
        value: function setGamificationEvents() {
            var _this3 = this;

            var request = {
                "url": window.location.href,
                "message": "init-1-1-chat"
            };
            this.$resultsContainer.find('.ldi-chat-init-action').not('.ldi-chat-event-applied').on('click', function () {

                $j.ajax({
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify(request),
                    url: _this3.loggerApiUrl
                });
            }).addClass('ldi-chat-event-applied');
        }
    }, {
        key: 'setResultsTitle',
        value: function setResultsTitle(count) {
            this.titleText = this.titleText.replace('{searchtext}', '"' + this.requestQuery.Criteria + '"').replace('{count}', count);

            this.$resultsTitle.text(this.titleText).show();
        }
    }, {
        key: 'showNoResults',
        value: function showNoResults() {
            this.$noResultsMessage.text(this.noResultsText).show();
        }
    }, {
        key: 'updateSkip',
        value: function updateSkip() {
            this.requestQuery.Skip += this.requestQuery.Count;
        }
    }, {
        key: 'lazyLoadHandler',
        value: function lazyLoadHandler() {
            var _this4 = this;

            clearTimeout(this.scrollHandler);

            this.scrollHandler = setTimeout(function () {
                var windowOffset = (window.pageYOffset || document.documentElement.scrollTop) + window.innerHeight;
                var containerBotOffset = _this4.$resultsContainer.offset().top + _this4.$resultsContainer.outerHeight();

                if (windowOffset > containerBotOffset) {
                    _this4.postRequest();
                }
            }, 500);
        }
    }, {
        key: 'postRequest',
        value: function postRequest() {
            var _this5 = this;

            if (!this.callToApiFlag) {
                return;
            }

            this.req = $j.ajax({
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(this.requestQuery),
                url: this.apiUrl,
                success: function success(res) {
                    _this5.latestResponse = res;
                    $j(window).trigger('ldi-search:Result');
                }
            });
        }
    }]);

    return LDISearchResults;
}();

$j(window).ready(function () {
    var $results = $j('.ldi-search-results');
    if (!$results.length) {
        return;
    }

    $results.each(function () {
        var searchResult = new LDISearchResults({
            element: $j(this)
        });
        searchResult.init();
    });
});