﻿function beautifyRenderings() {
    var beautifiedClass = "beautified";
    var replaceMapping = [
        { search: '&amp;lt;', replacement: '<' },
        { search: '&amp;gt;', replacement: '>' },
        { search: '&gt;', replacement: '>' },
        { search: '&lt;', replacement: '<' }
    ];

    function decode(str) {
        replaceMapping.forEach(e => {
            str = str.replace(new RegExp(e.search, 'g'), e.replacement);
        });
        return str;
    }

    function beautify(html) {
        return window.html_beautify(html, {
            'brace_style': "collapse",
            'break_chained_methods': false,
            'comma_first': false,
            'e4x': false,
            'end_with_newline': false,
            'indent_char': " ",
            'indent_inner_html': true,
            'indent_scripts': "normal",
            'indent_size': "4",
            'jslint_happy': false,
            'keep_array_indentation': false,
            'max_preserve_newlines': "5",
            'preserve_newlines': true,
            'space_before_conditional': true,
            'unescape_strings': false,
            'wrap_line_length': "0"
        });
    }

    var components = document.querySelectorAll("div.meta-component-wrapper:not(." + beautifiedClass + ")")
    for (var i = 0; i < components.length; i++) {
        var pre = document.createElement('pre');
        pre.className = "meta-rendering-code";
        pre.innerText = components[i].innerHTML.replace(/(\r\n|\n|\r)/gm, "");

        var html = decode(pre.innerHTML);
        html = beautify(html);
        html = html.replace(/</g, '&lt;').replace(/>/g, '&gt;');

        pre.innerHTML = html;
        components[i].innerText = "";
        components[i].appendChild(pre);
        if (!components[i].classList.contains(beautifiedClass)) {
            components[i].classList.add(beautifiedClass)
        }
    }
}

function addProxyToObject(obj, functionName, proxyFn) {
    var proxied = obj[functionName];
    obj[functionName] = function () {
        var result = proxied.apply(this, arguments);
        proxyFn(arguments);
        return result;
    };
}

function isSitecoreDefined() {
    return window.Sitecore && window.Sitecore.PageModes
}

beautifyRenderings();

isSitecoreDefined() && addProxyToObject(Sitecore.PageModes.PageEditor, "setModified", function () {
    beautifyRenderings();
});