﻿if (typeof ($xa) !== "undefined") {
    $xa.gridhiddencomponents = (function ($sc, document) {
        var api = {};
        if (!$sc) {
            return;
        }
        api.remove = function () {
            $sc("#wrapper").removeClass("grid-show-hidden");
        };

        api.init = function (classes) {
            $sc("#wrapper").addClass("grid-show-hidden");
        };

        return api;
    }(window.$sc, document));
}