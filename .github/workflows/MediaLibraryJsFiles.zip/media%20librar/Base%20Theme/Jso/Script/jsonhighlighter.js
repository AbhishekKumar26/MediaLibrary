﻿(function ($sc, sitecore) {
    if (!$sc || !sitecore ) {
        return;
    }
    var indentsize = 0,
    indentstep = 4;
    $sc(".json-component-wrapper").each(function (index, element) {
        if (!$sc(element).parent().hasClass("json-placeholder-wrapper")) {
            $sc(element).find(".token.comma,.token.open.bracket").each(function (inx, el) {
                var newlinew = $sc("<text>" + "\n" + "</text>");
                $sc(el).after(newlinew);
            });
            $sc(element).find(".token.close.bracket").each(function (inx, el) {
                var newlinew = $sc("<text>" + "\n" + "</text>");
                $sc(el).before(newlinew);
            });
            $sc(element).find(".token.punctuation.colon").each(function (index, el) {
                $sc(el).before($sc("<text> </text>")).after($sc("<text> </text>"));
            });
            var prevtoken = null;
            $sc(element).find(".token.property,.token.bracket", ".token.comma").each(function (index, el) {
                var $element = $sc(el);
                if ($element.hasClass("open")) {
                    if (prevtoken != null && (prevtoken.hasClass("comma") || (prevtoken.hasClass("bracket")))) {
                        renderIndent($element);
                    }
                    indentsize += indentstep;
                } else if ($element.hasClass("close")) {
                    indentsize -= indentstep;
                    renderIndent($element);
                } else  if ($element.hasClass("property")){
                    renderIndent($element);
                }

                prevtoken = $element;
            });
        }
    });

    function renderIndent(component) {
        var indent = "";
        for (var i = 0; i < indentsize; i++) {
            indent += " ";
        }
        component.before($sc("<text>" + indent + "</text>"));
    }
}(window.$sc, window.Sitecore))