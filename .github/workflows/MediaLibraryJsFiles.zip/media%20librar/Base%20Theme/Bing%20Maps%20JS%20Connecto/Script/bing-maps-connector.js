XA.connector.mapsConnector = (function ($, document) {
    var api = {},
        maps = [],
        callbacks = [],
        pins = [],
        infoboxes = [],
        loading = false,
        createFakeMap,
        map,
        getMapType,
        renderInfoBox,
        getFirstMap,
        createPin,
        addPin,
        addInfobox,
        lookup;

    getMapType = function (options) {
        switch (options.mode) {
            case 'Auto':
                {
                    return Microsoft.Maps.MapTypeId.auto;
                }
            case 'Roadmap':
                {
                    return Microsoft.Maps.MapTypeId.road;
                }
            case 'Birdseye':
                {
                    return Microsoft.Maps.MapTypeId.birdseye;
                }
            case 'Satellite':
                {
                    return Microsoft.Maps.MapTypeId.aerial;
                }
            default:
                {
                    return Microsoft.Maps.MapTypeId.auto;
                }
        }
    };

    addPin = function(mapId, pin, data) {
        //save POI id - this will be used while removing dynamic POIs from the map
        pin.id = data.id;
        if (pins[mapId]) {
            pins[mapId].push({ pin: pin, type: data.type});
        } else {
            pins[mapId] = [{ pin: pin, type: data.type}];
        }
    };

    createFakeMap = function() {
        var mapOptions = {
            zoom: 10,
            center: new Microsoft.Maps.Location("52.416213", "16.984423"),
            mapTypeId: Microsoft.Maps.MapTypeId.auto
        };
        return new Microsoft.Maps.Map(document.createElement("div"), mapOptions);
    };

    getFirstMap = function () {
        for(var map in maps) {
            if (maps.hasOwnProperty(map)) {
                return maps[map];
            }
        }
        return null;
    };

    initMap = function () {
        var i, length = callbacks.length;
        for (i = 0; i < length; i++) {
            callbacks[i].call();
        }
        loading = false;
    };

    createPin = function (data, mapId) {
        var pinOptions= {
                title: data.title,
                description: data.description,
                icon: data.icon
            },
            map = maps[mapId];
        var pin = new Microsoft.Maps.Pushpin(map.getCenter(), pinOptions);
        setTimeout(function(){
            var pinImage = new Image();
            pinImage.onload = function(){
                pin.setOptions({
                    width : pinImage.width,
                    height : pinImage.height
                });
            };
            pinImage.src = pinOptions.icon;
        },0);
        return pin;
    };

    renderInfoBox = function (e) {
        if (e.targetType == 'pushpin') {
            var mapId = e.target.data.mapId,
                map = maps[mapId],
                infobox;

            if (infoboxes.hasOwnProperty(mapId)) {
                map.entities.remove(infoboxes[mapId]);
                delete infoboxes[mapId];
            }

            infobox = new Microsoft.Maps.Infobox(e.target.getLocation(), null);
            map.entities.push(infobox);
            infobox.setOptions({ visible: true, description: e.target.data.html });
            infoboxes[mapId] = infobox;
        }
    };

    lookup = function(queryParams, successCallback, failCallback){
        var map = getFirstMap(),
            search,
            query,
            searchLoadedCallback;

        if (map == null) {
            map = createFakeMap();
        }

        searchLoadedCallback = function () {
            if (map === null) {
                return;
            }

            map.addComponent("searchManager", new Microsoft.Maps.Search.SearchManager(map));
            search = map.getComponent('searchManager');

            query = {
                where: queryParams.text,
                count: queryParams.maxResults || 1,
                callback: function(args){
                    if(typeof(args.results[0]) !== "undefined"){
                        successCallback(args.results);
                    }
                    else {
                        failCallback();
                    }

                },
                errorCallback: failCallback
            };

            search.geocode(query);
        };

        Microsoft.Maps.loadModule('Microsoft.Maps.Search', { callback: searchLoadedCallback });
    };

    api.loadScript = function (key, callback) {
        //save each callback and call them all when script will be loaded - protection for loading maps twice
        callbacks.push(callback);

        if (!loading) {
            loading = true;
            var script = document.createElement("script");
            script.setAttribute("src", "//dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0&onScriptLoad=initMap");
            script.setAttribute("type", "text/javascript");
            document.head.appendChild(script);
        }
    };

    api.showMap = function (mapId, options, viewBounds) {
        if (viewBounds instanceof Array) {
            mapOptions = {
                zoom: options.zoom,
                center: new Microsoft.Maps.Location(viewBounds[0], viewBounds[1]),
                mapTypeId: getMapType(options),
                credentials: options.key
            };
            map = new Microsoft.Maps.Map(document.getElementById(mapId), mapOptions);
        } else {
            mapOptions = {
                mapTypeId: getMapType(options),
                bounds: viewBounds
            };
            map = new Microsoft.Maps.Map(document.getElementById(mapId), mapOptions);
            if (options.poiCount < 2) {
                map.setView({ zoom: options.zoom });
            }
        }

        if (options.disableMapZoomOnScroll === "1") {
            Microsoft.Maps.Events.addHandler(map, 'mousewheel', function(e) {
                e.handled = true;
                return true;
            });
        }

        if (options.disableMapScrolling === "1") {
            Microsoft.Maps.Events.addHandler(map, 'mousedown', function (mouseEvent) {
                mouseEvent.handled = true;
            }); 
        }

        maps[mapId] = map;
    };

    api.renderPoi = function (mapId, data) {
        var map = maps[mapId],
            pushpin = createPin(data, mapId);

        addPin(mapId, pushpin, data);

        data.mapId = mapId;
        pushpin.data = data;
        map.entities.push(pushpin);
        pushpin.setLocation(new Microsoft.Maps.Location(data.latitude, data.longitude));

        Microsoft.Maps.Events.addHandler(pushpin, 'click', renderInfoBox);
    };

    api.renderDynamicPoi = function(mapId, data, getPoiContent) {
        var map = maps[mapId],
            pushpin = createPin(data, mapId);

        addPin(mapId, pushpin, data);

        data.mapId = mapId;
        pushpin.data = data;
        map.entities.push(pushpin);
        pushpin.setLocation(new Microsoft.Maps.Location(data.latitude, data.longitude));

        Microsoft.Maps.Events.addHandler(pushpin, 'click', function (e) {
            if (e.targetType == 'pushpin' && typeof (getPoiContent) === "function") {
                var poiId = data.id,
                    poiTypeId = data.poiTypeId,
                    poiVariantId = data.poiVariantId,
                    infobox;

                if (poiVariantId == null) {
                    return;
                }

                getPoiContent(poiId, poiTypeId, poiVariantId, function (data) {
                    if (infoboxes.hasOwnProperty(mapId)) {
                        map.entities.remove(infoboxes[mapId]);
                        delete infoboxes[mapId];
                    }
                    infobox = new Microsoft.Maps.Infobox(e.target.getLocation(), null);
                    map.entities.push(infobox);
                    infobox.setOptions({
                        visible: true,
                        title: data.title,
                        description: data.Html,
                        // offset the infobox enough to keep it from overlapping the pin.
                        offset: new Microsoft.Maps.Point(0, pushpin.getHeight())
                    });
                    infoboxes[mapId] = infobox;
                });
            }
        });
    };

    api.clearMarkers = function(mapId) {
        var mapPins,
            map = maps[mapId];

        if (pins.hasOwnProperty(mapId)) {
            mapPins = pins[mapId];
            for (var i = 0; i < mapPins.length; i++) {
                if (mapPins[i].type === "Dynamic") {
                    map.entities.remove(mapPins[i].pin);
                }
            }
            pins[mapId] = mapPins.filter(function (pinData) {
                if (pinData.type === "Static" || pinData.type === "MyLocation") {
                    return true;
                } else {
                    return false;
                }
            });
        }

        if (infoboxes[mapId]) {
            mapInfoboxes = infoboxes[mapId];
            for (var i = 0; i < mapInfoboxes.length; i++) {
                map.entities.remove(mapInfoboxes[i]);
            }
        }
    };

    api.updateMapPosition = function (mapId, defaultZoom) {
        var map = maps[mapId],
            mapPins = [],
            microsoftLocations = [],
            bounds;

        if (pins.hasOwnProperty(mapId)) {
            mapPins = pins[mapId];
        }

        mapPins.forEach(function (pinData) {
            microsoftLocations.push(new Microsoft.Maps.Location(pinData.pin.data.latitude, pinData.pin.data.longitude))
        }, this);

        map.setView({ bounds: Microsoft.Maps.LocationRect.fromLocations(microsoftLocations)});
        if (mapPins.length === 1) {
            map.setView({ zoom: defaultZoom });
        }
    };

    api.centerMap = function(mapId, data, centerMap, animate) {
       var map = maps[mapId];
       if (centerMap){
          map.setView({center: new Microsoft.Maps.Location(data.coordinates[0], data.coordinates[1]) });
       }
    };

    api.getCentralPoint = function (poisCoords) {

        var microsoftLocations = [],
            bounds;

        poisCoords.forEach(function (poi) {
            if (poi.latitude !== "" && poi.longitude !== "") {
                microsoftLocations.push(new Microsoft.Maps.Location(poi.latitude, poi.longitude))
            }
        }, this);

        bounds = Microsoft.Maps.LocationRect.fromLocations(microsoftLocations);

        return bounds;
    };

    api.locationAutocomplete = function(queryParams, successCallback, failCallback){
        var maxResults = queryParams.maxResults <= 0 ? 1 : queryParams.maxResults;

        lookup(queryParams,
        function(results){ //success
            var length = results.length >= maxResults ? maxResults : results.length,
                predictions = [];

            for (var i = 0; i < length; i++) {
                predictions.push(_.extend(results[i], {text : results[i].name, autocompleted : true}));
            }

            successCallback(predictions);
        },
        function(){ //fail
            failCallback();
        });
    };

    api.addressLookup = function (queryParams, successCallback, failCallback) {
        var result;
        if(queryParams.autocompleted){ //after autocomplete
            result = queryParams.location;
            if(result){
                successCallback([result.latitude,result.longitude]);
            }
            else {
                failCallback();
            }
        }
        else { //standard lookup
            lookup(queryParams,
            function(results){ //success
                result = results[0];
                if(result.location){
                    successCallback([result.location.latitude,result.location.longitude]);
                }
                else {
                    failCallback();
                }
            },
            function(){ //fail
                failCallback();
            });
        }
    };

    api.updateMyPoiLocation = function(mapId, coordinates, defaultZoom) {
        var mapPins,
            myLocationPin,
            map = maps[mapId];

        if (pins.hasOwnProperty(mapId)) {
            mapPins = pins[mapId];
            myLocationPin = mapPins.filter(function (pin) {
                if (pin.type === "MyLocation") {
                    return true;
                }
                return false;
            });
            if (myLocationPin.length > 0) {
                myLocationPin[0].pin.setLocation(new Microsoft.Maps.Location(coordinates[0], coordinates[1]));
                myLocationPin[0].pin.data.latitude = coordinates[0];
                myLocationPin[0].pin.data.longitude = coordinates[1];
                this.updateMapPosition(mapId, defaultZoom);
            }
        }
    };

    return api;

})(jQuery, document);
